<?php
/**
 * @package	HikaShop for Joomla!
 * @version	2.0.0
 * @author	hikashop.com
 * @copyright	(C) 2010-2012 HIKARI SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?><?php
if($this->identified){

	$mainId = 'hikashop_checkout_address_billing_only';
	$leftId = 'hikashop_checkout_billing_address';
	$mainClass = 'hikashop_checkout_address_billing_only';
	$leftClass = 'hikashop_checkout_billing_address';
	if($this->has_shipping) {
		$mainId = 'hikashop_checkout_address';
		$leftId = 'hikashop_checkout_address_left_part';
		$mainClass = 'hikashop_checkout_address';
		$leftClass = 'hikashop_checkout_address_left_part';
	}
	if(HIKASHOP_J30) {
		$mainClass .= ' row-fluid';
		$leftClass .= ' span6';
	}
?>
<div id="<?php echo $mainId; ?>" class="<?php echo $mainClass; ?>">
	<div id="<?php echo $leftId; ?>" class="<?php echo $leftClass; ?>">
		<fieldset>
			<legend><?php echo JText::_('HIKASHOP_BILLING_ADDRESS');?></legend>
<?php
	$this->type = 'billing';
	echo $this->loadTemplate('view');

	if($this->has_shipping) {
?>
		</fieldset>
	</div>
	<div id="hikashop_checkout_address_right_part" class="hikashop_checkout_address_right_part<?php if(HIKASHOP_J30){ echo ' span6';} ?>">
		<fieldset>
			<legend><?php echo JText::_('HIKASHOP_SHIPPING_ADDRESS');?></legend>
<?php
		$checked = '';
		$style = '';

		$override = false;
		if(!empty($this->currentShipping) && method_exists($this->currentShipping, 'getShippingAddress')) {
			$override = $this->currentShipping->getShippingAddress();
		}

		if($override === false) {
			$onclick = 'return hikashopSameAddress(this.checked);';
			if($this->shipping_address==$this->billing_address){
				$checked = 'checked="checked" ';
				$style = ' style="display:none"';
				$nb_addresses = count(@$this->addresses);
				if($nb_addresses==1){
					$address = reset($this->addresses);
					$onclick='if(!this.checked) { hikashopEditAddress(document.getElementById(\'hikashop_checkout_shipping_address_edit_'.$address->address_id.'\'),1,false); } '.$onclick;
				}
			}
?>
			<label for="same_address">
				<input class="hikashop_checkout_shipping_same_address inputbox" <?php echo $checked; ?>type="checkbox" id="same_address" name="same_address" value="yes" alt="Same address" onclick="<?php echo $onclick; ?>" />
				<?php echo JText::_('SAME_AS_BILLING');?>
			</label>
			<div class="hikashop_checkout_shipping_div" id="hikashop_checkout_shipping_div" <?php echo $style;?>>
<?php
			$this->type = 'shipping';
			echo $this->loadTemplate('view');
?>
			</div>
<?php
	 		} else {
?>				<span class="hikashop_checkout_billing_address_info"><?php echo $override;?></span>
<?php		}
		}
?>
		</fieldset>
	</div>
</div>
<div style="clear:both"></div>
<?php
}else{
}
